package com.example.chicco.safe20;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.maturita.safe20.R;

import java.io.OutputStream;

public class Login extends AppCompatActivity {



    BluetoothComIno bluetoothComIno= new BluetoothComIno("98:D3:35:00:AD:1D");
    OutputStream outStream;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        connetti();
    }

    public void VerificaUtente(View v){
        Intent i = new Intent(Login.this,MainActivity.class ); //creo nuovo intent che apre la nuova activity
        //connetti();
        startActivity(i); //apro activity

    } public  void connetti(){
        if (bluetoothComIno.connectToIno())
            Toast.makeText(this, "Connesso", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(this, bluetoothComIno.getErrorMessage(), Toast.LENGTH_SHORT).show();

    }

}
