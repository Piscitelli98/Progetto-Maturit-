package com.example.chicco.safe20;

import android.support.v4.app.Fragment;

/**
 * Created by ver01 on 25/01/2017.
 */
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.maturita.safe20.R;

public class GestioneAccessi extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_accessi, container, false);
        return rootView;
    }
}
