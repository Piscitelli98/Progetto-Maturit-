package com.example.chicco.safe20;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Handler;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.maturita.safe20.R;

import java.io.IOException;
import java.util.Set;

public class SplashScreen extends Activity implements Animation.AnimationListener{
    int timeout=3000; //variabile che indica la durata dello splash screen
    TextInputLayout psw;
    TextInputLayout User;
    ImageView imgLogo;
    Button login;
    BluetoothComIno bluetoothComIno= new BluetoothComIno("98:D3:35:00:AD:1D");//

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //imposto l' activity a schermo intero
        setContentView(R.layout.activity_splash_screen);

        User=(TextInputLayout)findViewById(R.id.TextUser);
        psw=(TextInputLayout)findViewById(R.id.pswSplash);
        imgLogo=(ImageView)findViewById(R.id.imgLogo);
        login=(Button)findViewById(R.id.btnLoginSplash);

        User.setVisibility(View.INVISIBLE);//rendo invisibili la casella username
        psw.setVisibility(View.INVISIBLE);//rendo invisibili la casella psw
        login.setVisibility(View.INVISIBLE);

        Animation muoviLogo= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.muovi_logo); //creo la nuova animazione
        muoviLogo.setFillAfter(true);
        muoviLogo.setAnimationListener(this);
        imgLogo.startAnimation(muoviLogo);

       /* boolean b = new Handler().postDelayed(new Runnable() {
            @Override
            public void run() { //chiamo un' azione che avviene dopo il timeout
                Intent i = new Intent(SplashScreen.this,Login.class ); //creo nuovo intent che apre la nuova activity dopo il timeout
                startActivity(i); //apro activity
                finish();
            }
        }, timeout);*/
        connetti();

    }
    public void VerificaUtente(View v){
        Intent i = new Intent(SplashScreen.this,MainActivity.class ); //creo nuovo intent che apre la nuova activity
        //connetti();
        i.putExtra("BluetoothObject",bluetoothComIno);
        startActivity(i); //apro activity

    }
    public  void connetti(){
        try {
            if (bluetoothComIno.connectToIno())
                Toast.makeText(this, "Connesso", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this, bluetoothComIno.getErrorMessage(), Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, bluetoothComIno.getErrorMessage(), Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {
        User.setVisibility(View.VISIBLE);//rendo visibile la casella username
        psw.setVisibility(View.VISIBLE);//rendo visibile la casella psw
        login.setVisibility(View.VISIBLE);
    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }

}
