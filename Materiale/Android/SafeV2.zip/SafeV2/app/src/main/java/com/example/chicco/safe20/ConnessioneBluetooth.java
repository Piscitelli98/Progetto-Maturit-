package com.example.chicco.safe20;

/**
 * Created by ver01 on 25/01/2017.
 */
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

//classi per la comunicazione bluetooth
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.widget.Button;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.maturita.safe20.R;

import java.io.IOException;
import java.io.OutputStream;
import java.util.UUID;

import static java.security.CryptoPrimitive.MAC;

public class ConnessioneBluetooth extends Fragment{
    // il nostro mac è questo: "98:D3:35:00:AD:1D"

//Attributi oggetti Android
    ToggleButton onOffBluetooth;
    Button inviaDati;
    BluetoothComIno bluetoothComIno;
    OutputStream outStream;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_connessione, container, false);
        onOffBluetooth= (ToggleButton) rootView.findViewById(R.id.TButtonConnessioneOnOffBluetooth);
        inviaDati= (Button) rootView.findViewById(R.id.buttonConnessioneInviaDati);
        bluetoothComIno= new BluetoothComIno("98:D3:35:00:AD:1D");
        //Metodo associato al bottone per connettersi al dispositivo bluetooth
        onOffBluetooth.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                if(onOffBluetooth.isChecked()) {
                    if (bluetoothComIno.connectToIno())
                        Toast.makeText(getActivity(), "Connesso", Toast.LENGTH_SHORT).show();
                    else
                        Toast.makeText(getActivity(), bluetoothComIno.getErrorMessage(), Toast.LENGTH_SHORT).show();
                }
                else {
                    if(bluetoothComIno.chiudiConnessione())
                        Toast.makeText(getActivity(), "Disconnesso", Toast.LENGTH_SHORT).show();
                    else
                        Toast.makeText(getActivity(), bluetoothComIno.getErrorMessage(), Toast.LENGTH_SHORT).show();
                }
            } // CHIUDE public void OnClick(View view)
        });//chiude il btnOnOffBluetooth.listener

        inviaDati.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                sendMessageBluetooth("ciao");
            }
        });
        return rootView;
    }
    private void sendMessageBluetooth(String message) {
        outStream=bluetoothComIno.getOutStream();
        if (outStream == null)
        {
            return;
        }
        byte[] msgBuffer = message.getBytes();
        try
        {
            outStream.write(msgBuffer);
            Toast.makeText(getActivity(), "Messaggio non Inviato", Toast.LENGTH_SHORT).show();
        }
        catch (IOException e)
        {
            Toast.makeText(getActivity(), "Messaggio non Inviato", Toast.LENGTH_SHORT).show();
        }
    }
}
