package com.example.chicco.safe20;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.os.Bundle;
import android.view.Window;

import com.maturita.safe20.R;

public class SplashScreen extends Activity {
    int timeout=3000; //variabile che indica la durata dello splash screen
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //imposto l' activity a schermo intero
        setContentView(R.layout.activity_splash_screen);
        boolean b = new Handler().postDelayed(new Runnable() {
            @Override
            public void run() { //chiamo un' azione che avviene dopo il timeout
                Intent i = new Intent(SplashScreen.this,Login.class ); //creo nuovo intent che apre la nuova activity dopo il timeout
                startActivity(i); //apro activity
                finish();
            }
        }, timeout);
    }
}
