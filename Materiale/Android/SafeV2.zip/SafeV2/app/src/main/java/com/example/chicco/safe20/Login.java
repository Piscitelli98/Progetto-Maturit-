package com.example.chicco.safe20;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.maturita.safe20.R;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void VerificaUtente(View v){
        Intent i = new Intent(Login.this,MainActivity.class ); //creo nuovo intent che apre la nuova activity
        startActivity(i); //apro activity
    }

}
