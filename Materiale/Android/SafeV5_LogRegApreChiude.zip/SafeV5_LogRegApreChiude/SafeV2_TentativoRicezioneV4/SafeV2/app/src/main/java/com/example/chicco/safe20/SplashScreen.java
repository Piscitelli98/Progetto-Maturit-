package com.example.chicco.safe20;

import android.app.Activity;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.maturita.safe20.R;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.UUID;

import static android.content.ContentValues.TAG;

public class SplashScreen extends Activity implements Animation.AnimationListener {
    int timeout = 3000; //variabile che indica la durata dello splash screen
    //Input utente
    TextInputLayout contenitoreUser;
    TextInputLayout pswInsert;
    AutoCompleteTextView userInsert;

    //Componenti android
    TextView tip;//"Non hai un acoount"
    ImageView imgLogo;
    Button login;
    TextView apriRegistrati;

    //Attributi vari
    private BluetoothComIno bluetoothComIno = new BluetoothComIno("98:D3:35:00:AD:1D");
    private String filename = "log.plpr";//nome del file di log

    //attributi comunicazione
    private static final String TAG = "bluetooth2";
    Handler h;
    final int RECIEVE_MESSAGE = 1;		// Status  for Handler
    private BluetoothSocket btSocket = null;
    private StringBuilder sb = new StringBuilder();
    private ConnectedThread mConnectedThread;
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static String address = "98:D3:35:00:AD:1D";
    private String msgControlloRicevuto;
    private BluetoothAdapter btAdapter = null;
    private String datiLogin="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //imposto l' activity a schermo intero
        setContentView(R.layout.activity_splash_screen);

        userInsert = (AutoCompleteTextView) findViewById(R.id.userSplash);
        pswInsert = (TextInputLayout) findViewById(R.id.pswSplash);
        imgLogo = (ImageView) findViewById(R.id.imgLogo);
        login = (Button) findViewById(R.id.btnLoginSplash);
        apriRegistrati = (TextView) findViewById(R.id.textViewRegistrati);
        contenitoreUser = (TextInputLayout) findViewById(R.id.TextUser);
        tip = (TextView) findViewById(R.id.textViewTip);

        userInsert.setVisibility(View.INVISIBLE);//rendo invisibili la casella username
        pswInsert.setVisibility(View.INVISIBLE);//rendo invisibili la casella psw
        login.setVisibility(View.INVISIBLE);
        apriRegistrati.setVisibility(View.INVISIBLE);
        contenitoreUser.setVisibility(View.INVISIBLE);
        tip.setVisibility(View.INVISIBLE);

        Animation muoviLogo = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.muovi_logo); //creo la nuova animazione
        muoviLogo.setFillAfter(true);
        muoviLogo.setAnimationListener(this);
        imgLogo.startAnimation(muoviLogo);

        h = new Handler() {
            public void handleMessage(android.os.Message msg) {
                final byte delimiter = 10;
                switch (msg.what) {
                    case RECIEVE_MESSAGE:                                                    // if receive massage
                        byte[] readBuf = (byte[]) msg.obj;
                        String strIncom = new String(readBuf, 0, 5);//, 0, msg.arg1				// create string from bytes array
                        sb.append(strIncom);			                                    // append string

                       // msgControlloRicevuto=strIncom;
                        /*int endOfLineIndex = sb.indexOf("-");							// determine the end-of-line
                        if (endOfLineIndex > 0) { 											// if end-of-line,
                            String sbprint = sb.substring(0, endOfLineIndex);				// extract string
                            sb.delete(0, sb.length());										// and clear

                        }*/
                }
         };
        };

       // btAdapter = BluetoothAdapter.getDefaultAdapter();
        bluetoothComIno.setmBluetoothAdapter();
        checkBTState();//Verifico se il bluetooth è attivo

        login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                prelevaDatiUtente();
                while(datiLogin.equals("")){

                }
                mConnectedThread.write("login_request;"+datiLogin+";%");	// Send "datiLogin" via Bluetooth
                //Toast.makeText(getBaseContext(), "Turn on LED", Toast.LENGTH_SHORT).show();
                verificaUtente();
            }
        });

    }
    @Override
    public void onResume(){
        super.onResume();
        Log.d(TAG, "...onResume - try connect...");
        connetti();
        mConnectedThread = new ConnectedThread(bluetoothComIno.getMmSocket());
        mConnectedThread.start();//faccio partire il thread che legge i valori inviati dal bluetooth
    }

    @Override
    public void onPause() {
        super.onPause();

        Log.d(TAG, "...In onPause()...");

        try     {
           // btSocket.close();
            bluetoothComIno.chiudiConnessione();
        } catch (Exception e2) {
            errorExit("Fatal Error", "In onPause() and failed to close socket." + e2.getMessage() + ".");
        }
    }

    private void checkBTState() {
        // Check for Bluetooth support and then check to make sure it is turned on
        // Emulator doesn't support Bluetooth and will return null
        if(bluetoothComIno.getmBluetoothAdapter()==null) {
            errorExit("Fatal Error", "Bluetooth not support");
        } else {
            if (bluetoothComIno.getmBluetoothAdapter().isEnabled()) {
                Log.d(TAG, "...Bluetooth ON...");
            } else {
                //Prompt user to turn on Bluetooth
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, 1);
            }
        }
    }
    private void errorExit(String title, String message){
        Toast.makeText(getBaseContext(), title + " - " + message, Toast.LENGTH_LONG).show();
        finish();
    }
    private void startApp() {//Apro l'activity principale
        Intent i = new Intent(SplashScreen.this, MainActivity.class); //creo nuovo intent che apre la nuova activity
        Bundle b = new Bundle();
        //String s="dasdwe";
        b.putString("login", datiLogin);
        //ConnessioneBluetooth obj = new ConnessioneBluetooth();
        //obj.setArguments(b);
        i.putExtras(b);
        startActivity(i); //apro activity

    }

    private boolean connetti() {//Metodo che tenta la connessione alla cassaforte
        boolean connesso=false;
        if (bluetoothComIno.connectToIno()){//se la connessione va a buon fine
            Toast.makeText(this, "Connesso", Toast.LENGTH_SHORT).show();
            connesso=true;
        }else {
            //Intent i = new Intent(SplashScreen.this, SplashScreen.class);
            //startActivity(i);
           Toast.makeText(SplashScreen.this, "Connessione non effettuata: " + bluetoothComIno.getErrorMessage(), Toast.LENGTH_SHORT).show();
        }
        return connesso;
    }

    private String getDatiLogin(AutoCompleteTextView u, String p) {//legge i valori inseriti dall'utente e restituisce
        String datiLogin = "";                                             // il valore nel formato in cui verrà scritto sul file
        //La psw è in md5
        String userName="";

        userName = u.getText().toString();
        datiLogin = userName + ";" + p;//creo la stringa con il formato predefinito "user;psw"
        return datiLogin;

    }
    private String getDatiPsw(TextInputLayout p) {//legge i valori inseriti dall'utente e restituisce
        String psw="";
        psw = p.getEditText().getText().toString();
        return psw;

    }

    private boolean fileExistance() {//Verifico l'esistenza del file
        boolean esiste = false;
        File file = new File(getFilesDir() + "/" + filename);
        if (file.exists())
            esiste = true;
        else
            esiste = false;
        return esiste;
    }

    private boolean cancellaFile(){//Elimina il file di log
        boolean eliminato=false;
        if(deleteFile(filename))
            eliminato=true;
        return eliminato;
    }

    private boolean scriviFile(String str) {//Scrive sul file di log
        boolean scritto = false;
        FileOutputStream outputStream;
        try {
            outputStream = openFileOutput(filename, Context.MODE_APPEND);//tento di aprire il file
            outputStream.write(str.getBytes());//scrivo nel buffer
            outputStream.close();//scrivo su file e chiudo il file
            scritto = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return scritto;
    }

    private String leggiFileLog() {//Legge file di log
        String line = "";//Riga letta
            try {
                FileInputStream fin = openFileInput(filename);
                int c;//Indice che permette di capire a che linea del file si è arrivati
                while ((c = fin.read()) != -1) {
                    line += Character.toString((char) c);
                }
            } catch (Exception e) {}

        return line;
    }


    private boolean sendMessageBluetooth(String message) {
        boolean inviato=false;
        OutputStream outStream;//stream per inviare messaggi all'arduino
        outStream=bluetoothComIno.getOutStream();
        if (outStream == null)
        {
            return inviato;
        }
        byte[] msgBuffer = message.getBytes();
        try
        {
            outStream.write(msgBuffer);
            Toast.makeText(this, "Messaggio Inviato", Toast.LENGTH_SHORT).show();
        }
        catch (IOException e)
        {
            Toast.makeText(this, "Messaggio non Inviato", Toast.LENGTH_SHORT).show();
        }
        return inviato;
    }
    public void prelevaDatiUtente(){

        //BeppeL;ciao1 --> login valido
        //cancellaFile();//test
        EncryptMd5 criptare= new EncryptMd5();//Instanzio l'oggetto che mi permette di criptare i dati
        //String datiLogin="";
        //scriviFile(criptare.computeMD5Hash("BeppeL;ciao1"));//test
        //userInsert.setText(leggiFileLog());test
        //String datiLogin="";

        String psw= getDatiPsw(pswInsert);//trasformo la password in stringa
        String pswCriptata=criptare.computeMD5Hash(psw);//cripto la stringa user;psw perchè il testo su file è criptato
        datiLogin=getDatiLogin(userInsert,pswCriptata);//prelevo i dati dalle editText creando una stringa in formato user;psw
        Log.d(TAG, "DatiLogin: "+ datiLogin);
        Log.d(TAG, "...Ho creato il testo criptato da inviare...");


    }

    public void verificaUtente(){
        try {

                byte[] readBuf=null ;
                mConnectedThread.mmInStream.read(readBuf);
                String strIncom = new String(readBuf, 0, 5);//, 0, msg.arg1				// create string from bytes array
                sb.append(strIncom);
                msgControlloRicevuto=strIncom;

        } catch (IOException e) {
            e.printStackTrace();
        }

        if(fileExistance()){//Verifico la presenza del file di log se è presente leggo i dati di accesso dal file e li confronto
            if(datiLogin.equals(leggiFileLog()/*datiLogin.equals(leggiFileLog())*/ )){//con quelli inseriti dall'utente
                startApp();
            }
            else
                Toast.makeText(this, "Login errata", Toast.LENGTH_SHORT).show();
        }else {
            if(msgControlloRicevuto!= null){
                if (msgControlloRicevuto.equals("TRUEE")) {
                    startApp();
                }
                else{
                    Toast.makeText(this, "LogIn Errato", Toast.LENGTH_SHORT).show();
                }
            } else
                Toast.makeText(this, "Nessun dato ricevuto", Toast.LENGTH_SHORT).show();
        }
    }

    public void apriRegistrati(View v){
        Intent i=new Intent(SplashScreen.this,Registrati.class);
        startActivity(i);
    }

    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {
        userInsert.setVisibility(View.VISIBLE);//rendo visibile la casella username
        pswInsert.setVisibility(View.VISIBLE);//rendo visibile la casella psw
        login.setVisibility(View.VISIBLE);
        apriRegistrati.setVisibility(View.VISIBLE);
        contenitoreUser.setVisibility(View.VISIBLE);
        tip.setVisibility(View.VISIBLE);
    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }

    private class ConnectedThread extends Thread {
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        public ConnectedThread(BluetoothSocket socket) {
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            // Get the input and output streams, using temp objects because
            // member streams are final
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (Exception e) { }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run() {

            byte[] buffer = new byte[256];  // buffer store for the stream
            int bytes; // bytes returned from read()
            Log.d(TAG, "...Sto ricevendo...");
            // Keep listening to the InputStream until an exception occurs
            while (true) {
                try {

                    // Read from the InputStream
                    bytes = mmInStream.read(buffer);		// Get number of bytes and message in "buffer"
                    h.obtainMessage(RECIEVE_MESSAGE, bytes, -1, buffer).sendToTarget();		// Send to message queue Handler
                } catch (IOException e) {
                    break;
                }
            }
        }

        /* Call this from the main activity to send data to the remote device */
        public void write(String message) {
            Log.d(TAG, "...Data to send: " + message + "...");
            byte[] msgBuffer = message.getBytes();
            try {
                mmOutStream.write(msgBuffer);
            } catch (IOException e) {
                Log.d(TAG, "...Error data send: " + e.getMessage() + "...");
            }
        }
    }

}
