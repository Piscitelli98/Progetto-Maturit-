package com.example.chicco.safe20;

import android.support.v4.app.Fragment;

/**
 * Created by ver01 on 25/01/2017.
 */
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.maturita.safe20.R;

import java.util.ArrayList;

public class GestioneAccessi extends Fragment {
    ListView listaAccessi;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_accessi, container, false);
        //apro la connessione oppure è già connesso
        //ti invio la richiesta carcando i risultati in un vettore
        //gli elementi del vettore li carico nel parametro "nome" dell'oggetto ListModel e in seguito li metto nell'add come sotto
        ArrayList accessi = new ArrayList();
        accessi.add(new ListModel(R.drawable.strongbox, "Amministratore"));
        accessi.add(new ListModel( R.drawable.strongbox, "Editor"));
        accessi.add(new ListModel( R.drawable.strongbox, "Autore"));
        accessi.add(new ListModel( R.drawable.strongbox, "Autore"));
        listaAccessi = (ListView) rootView.findViewById(R.id.listViewAccessi);
        MyAdapter madapter = new MyAdapter(getActivity(), accessi);
        listaAccessi.setAdapter(madapter);

        return rootView;
    }
}
