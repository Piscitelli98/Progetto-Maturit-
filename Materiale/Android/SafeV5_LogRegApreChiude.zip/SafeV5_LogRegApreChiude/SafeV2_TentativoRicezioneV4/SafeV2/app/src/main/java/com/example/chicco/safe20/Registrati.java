package com.example.chicco.safe20;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Handler;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.maturita.safe20.R;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class Registrati extends AppCompatActivity {


    private BluetoothComIno bluetoothComIno = new BluetoothComIno("98:D3:35:00:AD:1D");

    private OutputStream outStream;

    //Attributi interfaccia
    private EditText psw1;
    private EditText psw2;
    private AutoCompleteTextView user;
    private EditText pinCassaforte;
    private Button registratiBtn;


    //Attributi comunicazione
    private static final String TAG = "registrazione";
    Handler h;
    final int RECIEVE_MESSAGE = 1;        // Status  for Handler
    private String msgControlloRicevuto;
    private ConnectedThread mConnectedThread;
    private StringBuilder sb = new StringBuilder();
    String datiRegistrazione = "";

    //Dati prelevati dalla UI
    private String password1;//prendo valore di psw1
    private String password2; //prendo valore di psw2
    private String username; //prendo valore di username
    private String pin; //prendo valore di pin

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrati);

        psw1 = (EditText) findViewById(R.id.InputRegistratiPsw1);
        psw2 = (EditText) findViewById(R.id.InputRegistratiPsw2);
        user = (AutoCompleteTextView) findViewById(R.id.InputRegistratiUser);
        pinCassaforte = (EditText) findViewById(R.id.InputRegistratiPin);
        registratiBtn = (Button) findViewById(R.id.BtnRegistrati);

        h = new Handler() {
            public void handleMessage(android.os.Message msg) {
                final byte delimiter = 10;
                switch (msg.what) {
                    case RECIEVE_MESSAGE:                                                    // if receive massage
                        byte[] readBuf = (byte[]) msg.obj;
                        String strIncom = new String(readBuf, 0, 5);//, 0, msg.arg1				// create string from bytes array
                        sb.append(strIncom);                                                // append string

                        msgControlloRicevuto = strIncom;
                }
            }

            ;
        };

        // btAdapter = BluetoothAdapter.getDefaultAdapter();
        bluetoothComIno.setmBluetoothAdapter();

        registratiBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                mConnectedThread.write("registration_request;" + datiRegistrazione);    // Send "datiRegistrazione" via Bluetooth
                registraUtente();
            }
        });


    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "...onResume - try connect...");

        connetti();

        mConnectedThread = new ConnectedThread(bluetoothComIno.getMmSocket());
        mConnectedThread.start();//faccio partire il thread che legge i valori inviati dal bluetooth
    }

    @Override
    public void onPause() {
        super.onPause();

        Log.d(TAG, "...In onPause()...");

        try {
            bluetoothComIno.chiudiConnessione();
        } catch (Exception e2) {
            errorExit("Fatal Error", "In onPause() and failed to close socket." + e2.getMessage() + ".");
        }
    }

    private void errorExit(String title, String message) {
        Toast.makeText(getBaseContext(), title + " - " + message, Toast.LENGTH_LONG).show();
        finish();
    }

    private void startApp() {//Apro l'activity principale
        Intent i = new Intent(Registrati.this, SplashScreen.class); //creo nuovo intent che apre la nuova activity
        startActivity(i); //apro activity

    }

    private boolean connetti() {//Metodo che tenta la connessione alla cassaforte
        boolean connesso = false;
        if (bluetoothComIno.connectToIno()) {//se la connessione va a buon fine
            Toast.makeText(this, "Connesso", Toast.LENGTH_SHORT).show();
            connesso = true;
        } else {
            Toast.makeText(Registrati.this, "Connessione non effettuata: " + bluetoothComIno.getErrorMessage(), Toast.LENGTH_SHORT).show();
        }
        return connesso;
    }

    private String getDatiToSend(String username, String pswCrypted, String pinCrypted) {
        String s = username + ";" + pswCrypted /*+ ";" + pinCrypted*/;
        return s;
    }

    private void getDati() {
        //Prelevo i dati:
        password1 = psw1.getText().toString(); //prendo valore di psw1
        password2 = psw2.getText().toString(); //prendo valore di psw2
        username = user.getText().toString(); //prendo valore di username
        pin = pinCassaforte.getText().toString(); //prendo valore di pin
    }

    private void controlli(AutoCompleteTextView user, EditText psw1, EditText psw2, EditText pinCassaforte) {
        getDati();
        if (password1.matches("") || username.matches("") || pin.matches("") || password2.matches("")) {
            Toast.makeText(this, "Compilare tutti i campi", Toast.LENGTH_SHORT).show();
        }
        if (password1.compareTo(password2) == 0) {
            if (password1.length() < 5 && password2.length() < 6) {
                Toast.makeText(this, "La password deve essere formata da almeno 5 caratteri", Toast.LENGTH_SHORT).show();
            }
        } else
            Toast.makeText(this, "Password non corrispondono", Toast.LENGTH_SHORT).show();
        if (username.length() < 6) {
            Toast.makeText(this, "Username almeno 6 caratteri ", Toast.LENGTH_SHORT).show();
        }
    }

    public void registraUtente() {
        controlli(user, psw1, psw2, pinCassaforte);
        if (password1.matches("") == false && password1.compareTo(password2) == 0 && username.matches("") == false && pin.matches("") == false) { //se la password non è vuota ed è uguale all' altra
            EncryptMd5 cripta = new EncryptMd5();
            String pswCrypted = cripta.computeMD5Hash(password1);

            Log.d(TAG, "...Password Criptata: " + pswCrypted);
            String cryptedPin = cripta.computeMD5Hash(pin);
            Log.d(TAG, "...Pin Criptato: " + cryptedPin);

            datiRegistrazione = getDatiToSend(username, pswCrypted, cryptedPin);
            Log.d(TAG, "...DatiRegistrazione: " + datiRegistrazione);
            if (msgControlloRicevuto != null) {
                if (msgControlloRicevuto.equals("TRUEE")) {
                    Log.d(TAG, "...Registrazione effettuata...");
                    startApp();
                } else {
                    Toast.makeText(this, "Errore", Toast.LENGTH_SHORT).show();
                    Log.d(TAG, "...Registrazione non effettuata, errore...");
                }
            } else {
                Toast.makeText(this, "Nessun dato ricevuto", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "...Nessun dato ricevuto...");
            }
        }
    }

    private class ConnectedThread extends Thread {
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        public ConnectedThread(BluetoothSocket socket) {
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            // Get the input and output streams, using temp objects because
            // member streams are final
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (Exception e) {
            }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run() {

            byte[] buffer = new byte[256];  // buffer store for the stream
            int bytes; // bytes returned from read()
            Log.d(TAG, "...Sto ricevendo...");
            // Keep listening to the InputStream until an exception occurs
            while (true) {
                try {

                    // Read from the InputStream
                    bytes = mmInStream.read(buffer);        // Get number of bytes and message in "buffer"
                    h.obtainMessage(RECIEVE_MESSAGE, bytes, -1, buffer).sendToTarget();        // Send to message queue Handler
                } catch (IOException e) {
                    break;
                }
            }
        }

        /* Call this from the main activity to send data to the remote device */
        public void write(String message) {
            Log.d(TAG, "...Data to send: " + message + "...");
            byte[] msgBuffer = message.getBytes();
            try {
                mmOutStream.write(msgBuffer);
            } catch (IOException e) {
                Log.d(TAG, "...Error data send: " + e.getMessage() + "...");
            }
        }
    }

}