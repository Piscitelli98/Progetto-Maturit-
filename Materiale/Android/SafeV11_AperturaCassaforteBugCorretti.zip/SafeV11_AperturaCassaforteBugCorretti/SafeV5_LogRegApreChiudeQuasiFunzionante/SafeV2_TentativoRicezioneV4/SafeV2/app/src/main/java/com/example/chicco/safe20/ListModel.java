package com.example.chicco.safe20;

/**
 * Created by User_BeppeL on 10/03/2017.
 */

public class ListModel {


    private  int idImage;
    private  String nome;

    /*********** Set Methods ******************/


    public ListModel(){
        idImage=0;
        nome="";
    }
    public ListModel(int idImage, String nome){
        this.idImage=idImage;
        this.nome=nome;
    }
    public void setImage(int idImage)
    {
        this.idImage = idImage;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    /*********** Get Methods ****************/


    public int getImage()
    {
        return this.idImage;
    }

    public String getNome()
    {
        return this.nome;
    }
}
