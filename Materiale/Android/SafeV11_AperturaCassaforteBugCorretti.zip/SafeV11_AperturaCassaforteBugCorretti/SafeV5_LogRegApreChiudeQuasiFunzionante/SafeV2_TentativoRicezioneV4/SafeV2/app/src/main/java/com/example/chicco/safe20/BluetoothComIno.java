package com.example.chicco.safe20;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.UUID;

import android.widget.ToggleButton;

/**
 * Created by User_BeppeL on 27/01/2017.
 */

public class BluetoothComIno {
    //Attributi vari:
    String TAG="BluetoothComIno";
    String errorMessage; //utilizzo questa variabile per far si che quando si verifica un errrore, o non viene validata qualche condizione, si possa rintracciare
                         //facilmente l'errore chiamando anche il metodo getMessage() durante la fase di debug.
    //Attributi bluetooth
    public UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    BluetoothAdapter mBluetoothAdapter = null;
    BluetoothSocket mmSocket = null;
    BluetoothDevice mmDevice = null;
    OutputStream outStream;
    String MAC;// il nostro mac è questo: "98:D3:35:00:AD:1D"
    InputStream inputStream;
    public String getMac(){
        return MAC;
    }
    public BluetoothComIno(String mac) {
        MAC=mac;
    }

    public UUID getUuid() {
        return uuid;
    }

    public void setUuid(UUID uuid) {
        this.uuid = uuid;
    }

    public BluetoothAdapter getmBluetoothAdapter() {
        return mBluetoothAdapter;
    }

    public void setmBluetoothAdapter() {
        this.mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        Log.d(TAG, "...DefaultAdapter settato...");
    }

    public BluetoothSocket getMmSocket() {
        return mmSocket;
    }

    public void setMmSocket(BluetoothSocket mmSocket) {
        this.mmSocket = mmSocket;
    }

    public OutputStream getOutStream() {
        return outStream;
    }

    public void setOutStream(OutputStream outStream) {
        this.outStream = outStream;
    }
    public String getErrorMessage(){
        return errorMessage;
    }
    public void setErrorMessage(String mex){
        errorMessage=mex;
    }
    public InputStream getInputStream() {
        return inputStream;
    }

    public void setInputStream(InputStream inputStream) {
        this.inputStream = inputStream;
    }


    private boolean isSupported(BluetoothAdapter adapter) {//controlla che il bluetooth sia supportato
        boolean corretto = false;
        if (adapter == null) {//se non è supportato
            Log.d(TAG, "...Il bluetooth non è supportato...");
            setErrorMessage("Il bluetooth non è supportato");
        }
        else {
            corretto = true;
            Log.d(TAG, "...Il bluetooth è supportato...");
        }
        return corretto;
    }
    private boolean isActivated(BluetoothAdapter adapter){
        boolean corretto=false;
        if(!adapter.isEnabled()) {//se non è attivo
            setErrorMessage("Il bluetooth non è attivo");
            Log.d(TAG, "...Il bluetooth non è attivo...");
        }
        else {
            corretto = true;
            Log.d(TAG, "...Il bluetooth è attivo...");
        }
        return corretto;
    } public boolean chiudiConnessione(){
       boolean chiuso=false;
        try{
            outStream.close();
            mmSocket.close();
            chiuso=true;
            Log.d(TAG, "...Connessione chiusa...");
        }catch(IOException ceXC){
            chiuso=false;
            Log.d(TAG, "...Connessione non chiusa per eccezione...");
            setErrorMessage("Errore nella chiusura");
        }
        return chiuso;
    }
    public boolean connectToIno() {
        boolean connesso = false;
       // mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();//creo un adattatore per il bluetooth
        if (mBluetoothAdapter==null)
            setmBluetoothAdapter();
        if(isSupported(mBluetoothAdapter) && isActivated(mBluetoothAdapter)){//solo se il bluetooth è supportato ed è attivo
            mmDevice= mBluetoothAdapter.getRemoteDevice(MAC);//MAC address del bluetooth di arduino, Lo associo al dispositivo bluetooth
            //Indico il tipo di porta a cui connettersi
            try {
                mmSocket=mmDevice.createRfcommSocketToServiceRecord(uuid);
            } catch (IOException e) {
                e.printStackTrace();
                setErrorMessage("Errore con l'associazione alla porta RFCOMM");
            }
            try {
                Log.d(TAG, "...tento la connessione...");
                mmSocket.connect();//tento la connessione
                Log.d(TAG, "...Connesso...");
                outStream = mmSocket.getOutputStream();
                connesso=true;//sentinella che segnala che la connessione è stata stabilita
            }catch (IOException closeException) {
                closeException.getMessage();
                setErrorMessage("Conessione fallita");
                Log.d(TAG, "...Conessione fallita...");
                /*try {
                    //TENTA DI CHIUDERE IL SOCKET
                    outStream.close();
                    mmSocket.close();
                    setErrorMessage("Conessione fallita");
                } catch (IOException ceXC) {}*/
            }
        }else{// se il bluetooth non è supportato o non è attivato
           /* try{
                //TENTA DI CHIUDERE IL SOCKET

                outStream.close();
                mmSocket.close();
            }
            catch (IOException ceXC){
                setErrorMessage("Impossibile chiudere connessione");
            }*/

           System.out.println(getErrorMessage());
        }
        return connesso;
    }


}
