package com.example.chicco.safe20;

/**
 * Created by ver01 on 25/01/2017.
 */
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

//classi per la comunicazione bluetooth
import android.bluetooth.BluetoothSocket;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.maturita.safe20.R;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;


public class ConnessioneBluetooth extends Fragment{
    // il nostro mac è questo: "98:D3:35:00:AD:1D"

//Attributi oggetti Android
    Button openCassaforte;
    Button btn0;
    Button btn1;
    Button btn2;
    Button btn3;
    Button btn4;
    Button btn5;
    Button btn6;
    Button btn7;
    Button btn8;
    Button btn9;
    Button btnCanc;

    Button closeCassaforte;
    EditText pin;

//Attributi vari
    String datiLogin="asdfe";

//Attributi comunicazione
    private BluetoothComIno bluetoothComIno;
    private OutputStream outStream;
    private static final String TAG = "ConnessioneBluetooth";
    Handler h;
    final int RECIEVE_MESSAGE = 1;        // Status  for Handler
    private String msgControlloRicevuto;
    private ConnectedThread mConnectedThread;
    private StringBuilder sb = new StringBuilder();
    String datiOperazione = "";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_connessione, container, false);
        openCassaforte = (Button) rootView.findViewById(R.id.btnConnessioneBluetoothOpen);
        btn0 = (Button) rootView.findViewById(R.id.button0);
        btn1 = (Button) rootView.findViewById(R.id.button1);
        btn2 = (Button) rootView.findViewById(R.id.button2);
        btn3 = (Button) rootView.findViewById(R.id.button3);
        btn4 = (Button) rootView.findViewById(R.id.button4);
        btn5 = (Button) rootView.findViewById(R.id.button5);
        btn6 = (Button) rootView.findViewById(R.id.button6);
        btn7 = (Button) rootView.findViewById(R.id.button7);
        btn8 = (Button) rootView.findViewById(R.id.button8);
        btn9 = (Button) rootView.findViewById(R.id.button9);
        btnCanc = (Button) rootView.findViewById(R.id.buttonCancelletto);

        pin= (EditText)rootView.findViewById(R.id.editTextConnessioneBluetoothPin);
        pin.setKeyListener(null);
        //---Ricevo i dati di accesso----------
        Bundle b;
        b = getActivity().getIntent().getExtras();
        datiLogin=b.getString("login");
        Log.d(TAG, "datiLogin boundle: "+datiLogin);
        //------------------------------------------------------------

        bluetoothComIno= new BluetoothComIno("98:D3:35:00:AD:1D");

        h = new Handler() {
            public void handleMessage(android.os.Message msg) {
                final byte delimiter = 10;
                switch (msg.what) {
                    case RECIEVE_MESSAGE:                                                    // if receive massage
                        byte[] readBuf = (byte[]) msg.obj;
                        String strIncom = new String(readBuf, 0, 5);//, 0, msg.arg1				// create string from bytes array
                        sb.append(strIncom);                                                // append string

                        msgControlloRicevuto = strIncom;
                }
            }

            ;
        };
        bluetoothComIno.setmBluetoothAdapter();

        openCassaforte.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                mConnectedThread.write("open_request;" + datiOperazione);    // Send "datiOperazione" via Bluetooth
                apriCassa();
            }
        });
        btn0.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("0");
            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("1");
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("2");
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("3");
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("4");
            }
        });
        btn5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("5");
            }
        });
        btn6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("6");
            }
        });
        btn7.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("7");
            }
        });
        btn8.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("8");
            }
        });
        btn9.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("9");
            }
        });
        btnCanc.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int lungh=pin.getText().length();
                if(lungh>0) {
                    String stringSenzaUltimoN = pin.getText().toString().substring(0, lungh - 1);
                    pin.setText(stringSenzaUltimoN);
                }
            }
        });

        return rootView;
    }
    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "...onResume - try connect...");

        connetti();

        mConnectedThread = new ConnectedThread(bluetoothComIno.getMmSocket());
        mConnectedThread.start();//faccio partire il thread che legge i valori inviati dal bluetooth
    }

    @Override
    public void onPause() {
        super.onPause();

        Log.d(TAG, "...In onPause()...");

        try {
            bluetoothComIno.chiudiConnessione();
        } catch (Exception e2) {
            errorExit("Fatal Error", "In onPause() and failed to close socket." + e2.getMessage() + ".");
        }
    }

    private void errorExit(String title, String message) {
        Toast.makeText(getActivity(), title + " - " + message, Toast.LENGTH_LONG).show();
        getActivity().finish();
    }

    private boolean connetti() {//Metodo che tenta la connessione alla cassaforte
        boolean connesso = false;
        if (bluetoothComIno.connectToIno()) {//se la connessione va a buon fine
            Toast.makeText(getActivity(), "Connesso", Toast.LENGTH_SHORT).show();
            connesso = true;
        } else {
            Toast.makeText(getActivity(), "Connessione non effettuata: " + bluetoothComIno.getErrorMessage(), Toast.LENGTH_SHORT).show();
        }
        return connesso;
    }
    private String getPin(){
        String pinS="";
        return pinS= pin.getText().toString();
    }
    private String criptaPin(String pinS){
        EncryptMd5 cripta= new EncryptMd5();
        String pinCrypted="";
        pinCrypted= cripta.computeMD5Hash(pinS);

        Log.d(TAG, "...Pin criptato: "+ pinCrypted);
        return pinCrypted;
    }
    public void apriCassa(){
        //open_request;username;pin
        String pinToString=getPin();//Prelevo quanto inserito dall'utente
        Log.d(TAG, "...Pin inserito: "+ pinToString);
        if(pinToString.matches("")==false) {//se non è vuoto

            datiOperazione=criptaPin(pinToString);
            if (msgControlloRicevuto != null) {
                if (msgControlloRicevuto.equals("TRUEE")) {
                    Log.d(TAG, "...Il pin corrisponde...");
                    datiOperazione = datiLogin;
                    Toast.makeText(getActivity(),"Apertura in corso", Toast.LENGTH_LONG).show();
                    Log.d(TAG, "...Ho inviato la richiesta di apertura...");
                }else{
                    Toast.makeText(getActivity(), "Errore apertura", Toast.LENGTH_LONG).show();
                    Log.d(TAG, "...Errore apertura...");
                }
            }else {
                Toast.makeText(getActivity(), "Nessun dato ricevuto", Toast.LENGTH_LONG).show();
            }
                //Non c'è bisogno che l'arduino risponda perchè se l'operazione va a buon fine si vede
            } else {
                Toast.makeText(getActivity(), "Inserisci pin", Toast.LENGTH_LONG).show();
            }

    }
    public void chiudiCassa(){
        datiOperazione=datiLogin;
        Toast.makeText(getActivity(),"Chiusura in corso", Toast.LENGTH_LONG).show();
        Log.d(TAG, "...Ho inviato la richiesta di apertura...");
    }

    public void scriviN1(View v){
        pin.append("1");
    }
    public void scriviN2(View v){
        pin.append("2");
    }
    public void scriviN3(View v){
        pin.append("3");
    }
    public void scriviN4(View v){
        pin.append("4");
    }
    public void scriviN5(View v){
        pin.append("5");
    }
    public void scriviN6(View v){
        pin.append("6");
    }
    public void scriviN7(View v){
        pin.append("7");
    }
    public void scriviN8(View v){
        pin.append("8");
    }
    public void scriviN9(View v){
        pin.append("9");
    }
    public void scriviN0(View v){
        pin.append("0");
    }
    public void cancN(View v){
        int lungh=pin.getText().length();

        String stringSenzaUltimoN=pin.getText().toString().substring(0,lungh-1);
        pin.setText(stringSenzaUltimoN);

    }


    private class ConnectedThread extends Thread {
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        public ConnectedThread(BluetoothSocket socket) {
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            // Get the input and output streams, using temp objects because
            // member streams are final
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (Exception e) {
            }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run() {

            byte[] buffer = new byte[256];  // buffer store for the stream
            int bytes; // bytes returned from read()
            Log.d(TAG, "...Sto ricevendo...");
            // Keep listening to the InputStream until an exception occurs
            while (true) {
                try {

                    // Read from the InputStream
                    bytes = mmInStream.read(buffer);        // Get number of bytes and message in "buffer"
                    h.obtainMessage(RECIEVE_MESSAGE, bytes, -1, buffer).sendToTarget();        // Send to message queue Handler
                } catch (IOException e) {
                    break;
                }
            }
        }

        /* Call this from the main activity to send data to the remote device */
        public void write(String message) {
            Log.d(TAG, "...Data to send: " + message + "...");
            byte[] msgBuffer = message.getBytes();
            try {
                mmOutStream.write(msgBuffer);
            } catch (IOException e) {
                Log.d(TAG, "...Error data send: " + e.getMessage() + "...");
            }
        }
    }

}
