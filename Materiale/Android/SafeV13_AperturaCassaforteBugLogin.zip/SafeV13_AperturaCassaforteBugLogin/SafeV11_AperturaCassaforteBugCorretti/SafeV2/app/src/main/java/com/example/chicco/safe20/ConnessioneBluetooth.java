package com.example.chicco.safe20;

/**
 * Created by ver01 on 25/01/2017.
 */

import android.os.Handler;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

//classi per la comunicazione bluetooth
import android.bluetooth.BluetoothSocket;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.maturita.safe20.R;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;


public class ConnessioneBluetooth extends Fragment {
    // il nostro mac è questo: "98:D3:35:00:AD:1D"

    //Attributi oggetti Android
    Button openCassaforte;
    Button btn0;
    Button btn1;
    Button btn2;
    Button btn3;
    Button btn4;
    Button btn5;
    Button btn6;
    Button btn7;
    Button btn8;
    Button btn9;
    Button btnCanc;
    EditText pin;

    //Attributi vari
    private String datiLogin = "";
    private String pinToString = "";
    private String datiOperazione = "";
    private boolean connesso = false;
    private int conta=0;
    private boolean msgApertura=false;


    //Attributi comunicazione
    private BluetoothComIno bluetoothComIno;
    private OutputStream outStream;
    private static final String TAG = "ConnessioneBluetooth";
    public Handler h;
    final int RECIEVE_MESSAGE = 1;        // Status  for Handler
    private String msgControlloRicevuto="";
    private ConnectedThread mConnectedThread;
    private StringBuilder sb = new StringBuilder();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_connessione, container, false);
        openCassaforte = (Button) rootView.findViewById(R.id.btnConnessioneBluetoothOpen);
        btn0 = (Button) rootView.findViewById(R.id.button0);
        btn1 = (Button) rootView.findViewById(R.id.button1);
        btn2 = (Button) rootView.findViewById(R.id.button2);
        btn3 = (Button) rootView.findViewById(R.id.button3);
        btn4 = (Button) rootView.findViewById(R.id.button4);
        btn5 = (Button) rootView.findViewById(R.id.button5);
        btn6 = (Button) rootView.findViewById(R.id.button6);
        btn7 = (Button) rootView.findViewById(R.id.button7);
        btn8 = (Button) rootView.findViewById(R.id.button8);
        btn9 = (Button) rootView.findViewById(R.id.button9);
        btnCanc = (Button) rootView.findViewById(R.id.buttonCancelletto);

        pin = (EditText) rootView.findViewById(R.id.editTextConnessioneBluetoothPin);
        pin.setKeyListener(null);

        //---Ricevo i dati di accesso----------
        Bundle b;
        b = getActivity().getIntent().getExtras();
        datiLogin = b.getString("login");
        Log.d(TAG, "datiLogin boundle: " + datiLogin);
        //------------------------------------------------------------

        bluetoothComIno = new BluetoothComIno("98:D3:35:00:AD:1D");

        h = new Handler() {
            String stringaRicevuta="";
            public void handleMessage(android.os.Message msg) {

                switch (msg.what) {
                    case RECIEVE_MESSAGE:                                                    // if receive massage
                        byte[] readBuf = (byte[]) msg.obj;
                        String strIncom = new String(readBuf, 0,readBuf.length);//, 0, msg.arg1				//Qui è uno perchè i codici di errori sono singoli codici numerici
                        sb.append(strIncom);                                                // append string
                        if(sb.charAt(0)=='0')
                            msgApertura=true;
                        stringaRicevuta += sb.charAt(conta);
                        conta++;

                        if(conta>1 || msgApertura) {
                            stringaRicevuta +=strIncom;

                            for (int i=0; i<5;i++){
                                char charr=stringaRicevuta.charAt(i);
                                int f = charr;
                                if(stringaRicevuta.charAt(i)!= '\u0000')
                                    msgControlloRicevuto+=stringaRicevuta.charAt(i);

                            }
                            controllaComunicazione();
                            conta = 0;
                            msgControlloRicevuto=null;
                            stringaRicevuta=null;
                        }

                       // }

                }
            }

            ;
        };
        bluetoothComIno.setmBluetoothAdapter();

        openCassaforte.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
               // if (connesso) {//verifico che l'utente sia connesso alla cassaforte
                    apriCassa();//Setto larichiesta da inviare
                    // La passo al thread che la invia
                    mConnectedThread.write("open_request;" + datiOperazione);    // Invia richiesta di apertura via Bluetooth
                    Toast.makeText(getActivity(), "Inserisci l'impronta digitale quando il lettore inizia a lampeggiare", Toast.LENGTH_SHORT).show();
               // } else {
                  //  Toast.makeText(getActivity(), "Devi essere connesso per aprire la cassaforte", Toast.LENGTH_LONG).show();
                //}

            }
        });
        btn0.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("0");
            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("1");
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("2");
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("3");
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("4");
            }
        });
        btn5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("5");
            }
        });
        btn6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("6");
            }
        });
        btn7.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("7");
            }
        });
        btn8.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("8");
            }
        });
        btn9.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pin.append("9");
            }
        });
        btnCanc.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int lungh = pin.getText().length();
                if (lungh > 0) {
                    String stringSenzaUltimoN = pin.getText().toString().substring(0, lungh - 1);
                    pin.setText(stringSenzaUltimoN);
                }
            }
        });

        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "...onResume - try connect...");
        while (!connesso)
            connetti();

        mConnectedThread = new ConnectedThread(bluetoothComIno.getMmSocket());
        mConnectedThread.start();//faccio partire il thread che legge i valori inviati dal bluetooth
    }

    @Override
    public void onPause() {
        super.onPause();

        Log.d(TAG, "...In onPause()...");

        try {
            bluetoothComIno.chiudiConnessione();
        } catch (Exception e2) {
            errorExit("Fatal Error", "In onPause() and failed to close socket." + e2.getMessage() + ".");
        }
    }

    private void errorExit(String title, String message) {
        Toast.makeText(getActivity(), title + " - " + message, Toast.LENGTH_SHORT).show();
        getActivity().finish();
    }

    private boolean connetti() {//Metodo che tenta la connessione alla cassaforte

        if (bluetoothComIno.connectToIno()) {//se la connessione va a buon fine
            Toast.makeText(getActivity(), "Connesso", Toast.LENGTH_SHORT).show();
            connesso = true;
        } else {
            Toast.makeText(getActivity(), "Connessione non effettuata: " + bluetoothComIno.getErrorMessage(), Toast.LENGTH_SHORT).show();
        }
        return connesso;
    }

    private String getPin() {//prelevo il pin inserito dall'utente e lo ritorno in formato String
        String pinS = "";
        return pinS = pin.getText().toString();
    }

    public void apriCassa() {//Creo la stringa da inviare alla cassaforte per aprire la cassaforte
        //open_request;username;pin--> formato richiesta, protocollo
        if (!connesso) {
            connetti();
        }
        pinToString = getPin();//richiamo il metodo per prelevare ilpin inserito dall'utente
        Log.d(TAG, "...Pin inserito: " + pinToString);
        if (pinToString.matches("") == false) {//Verifico che non sia stato lasciato vuoto il campo di inserimento del pin
            //Ricordarsi di aggiungere la codifica del pin della cassaforte

            //Eseguo il parse perchè dal boundle ricevo anche la psw
            //Una volta eseguito il parse posso settare la variabile datiOperazione che sarà poi mandata dal thread
            datiOperazione = parseDatiLogin(datiLogin) + ";" + pinToString + ";%";
        } else {
            Toast.makeText(getActivity(), "Inserisci pin", Toast.LENGTH_LONG).show();
        }

    }

    public void controllaComunicazione() {//Metodo che controlla il messaggio ricevuto dalla cassaforte
        if (msgControlloRicevuto != null) {
            if (msgControlloRicevuto.equals("0")) {//Se ricevo zero tutto è andato a buon fine
                Log.d(TAG, "...Il pin corrisponde...");
                Toast.makeText(getActivity(), "Apertura in corso", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "...Ho inviato la richiesta di apertura...");
            }
            if (msgControlloRicevuto.equals("-1")) {//-1 identifica che lo username non è riconosciuto(Ridondante)
                Toast.makeText(getActivity(), "Username non trovato", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "...Errore apertura...");
            }
            if (msgControlloRicevuto.equals("-2")) {//-2 identifica che non è corretto il pin inserito
                Toast.makeText(getActivity(), "Pin errrato", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "...Errore apertura...");
            }
            if (msgControlloRicevuto.equals("-3")) {//-2 identifica che non è corretto il pin inserito
                Toast.makeText(getActivity(), "Cassaforte già aperta", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "...Errore apertura...");
            }
        } else {
            Toast.makeText(getActivity(), "Nessun dato ricevuto", Toast.LENGTH_SHORT).show();
        }
    }

    private String parseDatiLogin(String dati) {//eseguo il parse della variabile datiLogin ricevuta dall'activity precedente
        //perchè la variabile ricevuta è nel formato "user;psw", e a me serve estrapolare solamente lo username
        String username = "";
        for (int i = 0; i < dati.length(); i++) {
            if (dati.charAt(i) == ';') {
                username = dati.substring(0, dati.indexOf(';'));
                break;
            }
        }
        return username;
    }




    private class ConnectedThread extends Thread {
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        public ConnectedThread(BluetoothSocket socket) {
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            // Get the input and output streams, using temp objects because
            // member streams are final
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (Exception e) {
            }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run() {

            byte[] buffer = new byte[256];  // buffer store for the stream
            int bytes; // bytes returned from read()
            Log.d(TAG, "...Sto ricevendo...");
            // Keep listening to the InputStream until an exception occurs
            while (true) {
                try {

                    // Read from the InputStream
                    bytes = mmInStream.read(buffer);        // Get number of bytes and message in "buffer"
                    h.obtainMessage(RECIEVE_MESSAGE, bytes, -1, buffer).sendToTarget();        // Send to message queue Handler
                } catch (IOException e) {
                    break;
                }
            }
        }

        /* Call this from the main activity to send data to the remote device */
        public void write(String message) {
            Log.d(TAG, "...Data to send: " + message + "...");
            byte[] msgBuffer = message.getBytes();
            try {
                mmOutStream.write(msgBuffer);
            } catch (IOException e) {
                Log.d(TAG, "...Error data send: " + e.getMessage() + "...");
            }
        }
    }

}
