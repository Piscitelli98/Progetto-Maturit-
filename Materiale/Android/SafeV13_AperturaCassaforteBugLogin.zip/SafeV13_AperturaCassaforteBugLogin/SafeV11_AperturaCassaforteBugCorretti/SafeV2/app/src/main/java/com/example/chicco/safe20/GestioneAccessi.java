package com.example.chicco.safe20;

import android.content.Context;
import android.support.v4.app.Fragment;

/**
 * Created by ver01 on 25/01/2017.
 */
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.maturita.safe20.R;

import java.io.File;
import java.io.File.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class GestioneAccessi extends Fragment {
    ListView listaAccessi;
    private String filename = "accessi.plpr";//nome del file di log

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_accessi, container, false);
        //apro la connessione oppure è già connesso
        //ti invio la richiesta carcando i risultati in un vettore
        //gli elementi del vettore li carico nel parametro "nome" dell'oggetto ListModel e in seguito li metto nell'add come sotto

        cancellaFile();//per test
        scriviFile("FedericoPiscitelli;");
        scriviFile("GiuseppeLeggio;");
        scriviFile("DanielePerego;");
        scriviFile("RosselliMattia;");
        ArrayList fileLetto = new ArrayList();
        ArrayList accessi = new ArrayList();

        String nome = "";
        fileLetto = leggiFileLog();
        for (int i = 0; i < fileLetto.size(); i++) {
            nome = fileLetto.get(i).toString();
            accessi.add(new ListModel(R.drawable.strongbox, nome));
            nome = "";
        }
        listaAccessi = (ListView) rootView.findViewById(R.id.listViewAccessi);
        MyAdapter madapter = new MyAdapter(getActivity(), accessi);
        listaAccessi.setAdapter(madapter);

        return rootView;
    }

    private boolean fileExistance() {//Verifico l'esistenza del file
        boolean esiste = false;
        File file = new File(getActivity().getFilesDir() + "/" + filename);
        if (file.exists())
            esiste = true;
        return esiste;
    }

    private boolean cancellaFile() {//Elimina il file di log
        boolean eliminato = false;
        if (getActivity().deleteFile(filename))
            eliminato = true;
        return eliminato;
    }

    private boolean scriviFile(String str) {//Scrive sul file di log
        boolean scritto = false;
        FileOutputStream outputStream;
        try {
            outputStream = getActivity().openFileOutput(filename, Context.MODE_APPEND);//tento di aprire il file

            outputStream.write(str.getBytes());//scrivo nel buffer
            outputStream.close();//scrivo su file e chiudo il file
            scritto = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return scritto;
    }

    private ArrayList leggiFileLog() {//Legge file di log
        String line = "";//Riga letta
        ArrayList lines = new ArrayList();
        try {
            FileInputStream fin = getActivity().openFileInput(filename);
            int c;//Indice che permette di capire a che linea del file si è arrivati
            while ((c = fin.read()) != -1) {
                line += Character.toString((char) c);
                if (c == ';') {
                    lines.add(line);
                    line = "";
                }
            }
        } catch (Exception e) {
        }

        return lines;
    }

}
