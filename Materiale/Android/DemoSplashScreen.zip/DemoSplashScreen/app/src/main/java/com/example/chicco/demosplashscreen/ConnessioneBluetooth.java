package com.example.chicco.demosplashscreen;

/**
 * Created by ver01 on 25/01/2017.
 */
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

//classi per la comunicazione bluetooth
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.IOException;
import java.io.OutputStream;
import java.util.UUID;

import static java.security.CryptoPrimitive.MAC;

public class ConnessioneBluetooth extends Fragment{
    public UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
//Attributi bluetooth
    BluetoothAdapter mBluetoothAdapter=null;
    BluetoothSocket mmSocket=null;
    BluetoothDevice mmDevice=null;
    OutputStream outStream;
//Attributi oggetti Android
    ToggleButton onOffBluetooth;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_connessione, container, false);
        onOffBluetooth= (ToggleButton) rootView.findViewById(R.id.TButtonConnessioneOnOffBluetooth);
        //Metodo associato al bottone per connettersi al dispositivo bluetooth
        onOffBluetooth.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                if(onOffBluetooth.isChecked())//controlla che sia attivo il toggle button{
                    mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
                if (mBluetoothAdapter == null)//controlla se il devices è supportato{
                    // IL BLUETOOTH NON E' SUPPORTATO
                    Toast.makeText(MainActivity., "BlueTooth non supportato", Toast.LENGTH_LONG);

                onOffBluetooth.setChecked(false);
            }
            else{
                if (!mBluetoothAdapter.isEnabled())//controlla che sia abilitato il devices
                {
                    //  NON E' ABILITATO IL BLUETOOTH
                    Toast.makeText(MainActivity.this, "BlueTooth non abilitato", Toast.LENGTH_LONG).show();
                    onOffBluetooth.setChecked(false);
                }
                else{
                    //  IL BLUETOOTH E' ABILITATO
                    mmDevice=mBluetoothAdapter.getRemoteDevice(<MAC>);//MAC address del bluetooth di arduino
                    try{
                        mmSocket=mmDevice.createRfcommSocketToServiceRecord(uuid);
                    }
                    catch (IOException e){
                        onOffBluetooth.setChecked(false);
                    }
                    try{
                        // CONNETTE IL DISPOSITIVO TRAMITE IL SOCKET mmSocket
                        mmSocket.connect();
                        outStream = mmSocket.getOutputStream();
                        Toast.makeText(MainActivity.this, "ON",  Toast.LENGTH_SHORT).show();//bluetooth è connesso
                    }
                    catch (IOException closeException){
                        onOffBluetooth.setChecked(false);
                        try{
                            //TENTA DI CHIUDERE IL SOCKET
                            mmSocket.close();
                        }
                        catch (IOException ceXC){
                        }
                        Toast.makeText(MainActivity.this, "connessione non rieuscita",  Toast.LENGTH_SHORT).show();
                    }
                }   //CHIUDE l'else di isEnabled
            }  //CHIUDE l'else di mBluetoothAdapter == null
        }  // CHIUDE if (tgb.isChecked())
        else{
            try{
                //TENTA DI CHIUDERE IL SOCKET
                outStream.close();
                mmSocket.close();
            }
            catch (IOException ceXC){}
        }
    } // CHIUDE public void OnClick(View view)
});//chiude il tgb.listener

        return rootView;
    }
}
