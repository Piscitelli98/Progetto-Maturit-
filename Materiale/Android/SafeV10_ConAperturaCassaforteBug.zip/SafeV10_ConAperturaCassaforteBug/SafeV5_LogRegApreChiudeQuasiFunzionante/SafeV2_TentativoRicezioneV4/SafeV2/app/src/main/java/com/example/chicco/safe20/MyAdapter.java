package com.example.chicco.safe20;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maturita.safe20.R;

import java.util.ArrayList;

/**
 * Created by User_BeppeL on 10/03/2017.
 */
public class MyAdapter extends BaseAdapter {

        private Activity mActivity;
        private ArrayList<ListModel> listaAutori;
        private static LayoutInflater inflater = null;

        public MyAdapter(Activity a, ArrayList list) {
            mActivity = a;
            listaAutori = list;
            inflater = (LayoutInflater) mActivity
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return listaAutori.size();
        }

        @Override
        public Object getItem(int item) {
            // TODO Auto-generated method stub
            return item;
        }

        @Override
        public long getItemId(int item) {
            // TODO Auto-generated method stub
            return item;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View vi = convertView;
            if (convertView == null)
                vi = inflater.inflate(R.layout.style_listview_accessi, null);

            TextView nome = (TextView) vi.findViewById(R.id.nome);
            ImageView imgAccesso = (ImageView) vi.findViewById(R.id.imageAccesso);
            ListModel ogg = listaAutori.get(position);
            nome.setText(ogg.getNome());
           // setImageDrawable(mActivity.getResources().getDrawable(ogg.getImage()));//questo metodo richiede l'api 21
            imgAccesso.setImageResource(R.drawable.strongbox);
            // TODO Auto-generated method stub
            return vi;
        }

    }
